create definer = lian7@`%` trigger review_update
    before insert
    on Reviews
    for each row
begin
#         SET @flag =(SELECT UserID
#         FROM Reviews
#         WHERE (UserID = new.UserID) and (GameName = new.GameName))
#         limit 1;
#         IF  (new.UserID in (select UserID from Reviews)) then
#             DELETE FROM Reviews
#             WHERE (UserID = new.UserID) and (GameName = new.GameName);
#         end if;
        if new.Comment is not null then
            if ((new.Comment like '%sb%') or (new.Comment like '%fuck%') or (new.Comment like '%shit%'))  then
                set new.Comment = 'This comment contains spam and has been blocked';
            end if;
        end if;
        SET @average =
            (SELECT avg(Score)
                FROM Reviews
                WHERE GameName = new.GameName
                group by GameName);
        update GamePages set AvgScore = @average where GameName = NEW.GameName;

    end;

