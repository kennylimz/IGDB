create
    definer = mingzhi2@`%` procedure Mix(IN uid int)
begin
declare G_temp varchar(50);
declare GCT int;
declare Genre_grade int;
declare done int default 0;


declare loading cursor for (
   select Genre, count(Genre)
   from History natural join Genres
   where UserID = uid
   group by Genre
   );


declare continue handler for not found set done = 1;

drop table if exists GenrePref;
create table GenrePref(
Genre varchar(50),
Genre_grade int
);

open loading;
repeat
   fetch loading into G_temp, GCT;
   if GCT > 5 then
      set Genre_grade = 5;
   elseif GCT<=5 then
      set Genre_grade = 0;
   end if;

   insert ignore into GenrePref
   values(G_temp, Genre_grade);
until done
end repeat;
close loading;


drop table if exists Mid1;
create table Mid1(
    GameName_tb varchar(254),
    Platform_tb varchar(254),
    ReleaseDate_tb varchar(254),
    Genre_tb varchar(254),
    OfficialURL_tb varchar(254)
);

drop table if exists Mid2;
create table Mid2(
    PrefPlatform varchar(254),
    max_grade int
);

insert into Mid1
    (select GameName, Platform, ReleaseDate, Genre, OfficialURL
     from (Games natural join Genres)
              join GenrePref using (Genre)
     where GameName not in (select GameName from History where UserID = uid)
     order by (MetaScore+Genre_grade) DESC, ReleaseDate DESC
     );

insert into Mid2
    (select distinct Platform, max(GenrePref.Genre_grade)
     from (Games natural join Genres) join GenrePref using (Genre)
     where GameName in (select GameName from History where UserID = uid)
     group by Platform
     order by max(Genre_grade) DESC, max(ReleaseDate) DESC
     limit 5
    );

select distinct GameName_tb from Mid1
where Platform_tb in (select PrefPlatform from Mid2)
group by GameName_tb
order by max(ReleaseDate_tb) DESC
limit 25;


end;

